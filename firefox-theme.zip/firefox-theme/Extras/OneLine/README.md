# How to apply.
<ol><li>Delete: <code>ogx_menu.css</code> from: <code>chrome/components</code>. </li>

  <li>Add the file <code>ogx_oneline.css</code> into the <code>chrome/components</code> folder.</li>
  <li>Put some icons from the toolbar into the overflow menu to make enough space to the oneline theme, Thats all. 💙</li></ol>

<ul><li>PD: Don't forget to make a backup of the <code>ogx_menu.css</code>file if you want to comeback to the original theme.</li></ul>

![imagen](https://user-images.githubusercontent.com/22057609/182465046-173cdc9f-d34d-4726-ab46-5b31315edfd0.png)

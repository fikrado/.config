The click in the "sound icon" makes media content pause or play  in some websites, you could try it if you want.
1.- Open a tab in "Extension and themes" and move the file to install it. 
